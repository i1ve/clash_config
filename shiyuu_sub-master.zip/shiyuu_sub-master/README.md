Private subscription files
